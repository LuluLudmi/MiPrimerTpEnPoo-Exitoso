package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.Actividad.AutoClasico;
import ar.org.centro8.curso.java.Actividad.AutoNuevo;
import ar.org.centro8.curso.java.Actividad.Colectivo;
import ar.org.centro8.curso.java.Actividad.Radio;

public class TestVehiculos {
    public static void main(String[] args) {

        // Crear radios disponibles
        Radio radio1 = new Radio("Sony", 100);
        Radio radio2 = new Radio("Panasonic", 80);
        Radio radio3 = new Radio("Pioneer", 120);
        Radio radio4 = new Radio("JVC", 90);
        Radio radio5 = new Radio("Philips", 95); // nueva radio para evitar usar null
        Radio radio6 = new Radio("Alpine", 140);
        Radio radio7 = new Radio("Noblex", 60);
        // Crear AutoClasico sin radio, luego asignarla
        AutoClasico clasico = new AutoClasico("Rojo", "Ford", "F-100", 600000.0);
        clasico.setRadio(radio1); // radio1 se marca como ocupada
        // Crear un segundo AutoClasico
        AutoClasico clasico55 = new AutoClasico("Amarillo ", "Renault", "19", 450000.0);

        // Crear AutoNuevo con radio2

        AutoNuevo nuevo = new AutoNuevo("Negro", "Toyota", "Corolla", 59000000.0, radio2);

        // Crear dos colectivos sin radio
        Colectivo bondi = new Colectivo("Amarillo", "Mercedes", "Benz 500", 50000.0);
        Colectivo bondi2 = new Colectivo("Verde", "Mercedes", "kant", 8000000.0);

        // Mostrar estados
        System.out.println(clasico);
        System.out.println(clasico55);
        System.out.println(nuevo);
        System.out.println(bondi);
        System.out.println(bondi2);

        // Intentar usar radio2 en otro vehículo (está en uso por clasico).
        // RECORDAR QUE EL AUTONUEVO TIENE RADIO2.
        System.out.println("\nIntentando asignar radio2 al colectivo (ya está en uso):");
        bondi.setRadio(radio2); // No se debería asignar
        System.out.println("Radio del colectivo: " + bondi.getRadio());
        System.out.println();

        // Liberar radios del diferentes vehiculos y reasignarla
        System.out.println("\nLiberando radio1 del auto clásico y asignándola al primer colectivo:");
        clasico.setRadio(null); // radio1 queda libre
        bondi.setRadio(radio1); // Ahora sí puede usarse
        System.out.println("Radio del primer colectivo: " + bondi.getRadio());
        System.out.println("\nLiberando radio1 del primer colectivo y asignándola nuevamente al auto clasico:");
        bondi.setRadio(null); // radio1 queda libre
        clasico.setRadio(radio1); // Ahora sí puede usarse
        System.out.println("Radio del auto clasico: " + clasico.getRadio());
        System.out.println("\nLiberando radio1 del auto clásico y asignándola al auto clasico 55:");
        clasico.setRadio(null); // radio1 queda libre
        clasico55.setRadio(radio1); // Ahora sí puede usarse
        System.out.println("Radio del auto clasico 55 : " + clasico55.getRadio());

        System.out.println("\nIntentando asignar radio2 al segundo colectivo (ya está en uso):");
        bondi2.setRadio(radio2); // No se debería asignar ya que esta en uso por auto nuevo
        System.out.println("Radio del Segundo colectivo : " + bondi2.getRadio());
        System.out.println();

        // Crear más vehículos con radios
        AutoNuevo nuevo2 = new AutoNuevo("Blanco", "Honda", "Civic", 72000000.0, radio3); // radio3 es válida
        AutoClasico clasico2 = new AutoClasico("Verde", "Chevrolet", "Impala", 45000000);
        clasico2.setRadio(radio4); // radio4 disponible

        // AutoNuevo con una nueva radio
        AutoNuevo nuevo3 = new AutoNuevo("Gris", "Fiat", "Cronos", 89000000.0, radio5); //
        AutoNuevo nuevo22 = new AutoNuevo("Rosa", "Peugeot", "208", 28921666.0, null);

        AutoNuevo nuevo90 = new AutoNuevo("Rojo", "Toyota", "Yaris", 8000000.0, radio6);
        AutoClasico clasico34 = new AutoClasico("Verde", "Chevy", "Impala", 5000000.0);
        clasico34.setRadio(radio6); // ¡Error! radio1 ya está ocupada

        System.out.println("\nMás vehículos con sus respectivas radios:");
        System.out.println(nuevo2);
        System.out.println(clasico2);
        System.out.println(nuevo3);
        System.out.println(nuevo22);
        System.out.println(clasico34);
        System.out.println(nuevo90);
    }
}