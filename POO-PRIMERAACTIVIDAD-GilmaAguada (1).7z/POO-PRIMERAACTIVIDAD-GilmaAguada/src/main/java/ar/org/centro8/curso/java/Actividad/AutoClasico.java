package ar.org.centro8.curso.java.Actividad;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString(callSuper = true)

public class AutoClasico extends Vehiculo {
    public AutoClasico(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public String getTipoVehiculo() {
        return "Auto Clásico";
    }
}
