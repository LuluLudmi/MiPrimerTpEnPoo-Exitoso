package ar.org.centro8.curso.java.Actividad;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class Radio {
    private String marca;
    private int potencia;
    private boolean disponible; // Referencia al vehículo que la contiene

    public Radio(String marca, int potencia) {
        this.marca = marca;
        this.potencia = potencia;
        this.disponible = true;
    }

    public String getMarca() {
        return marca;
    }

    public int getPotencia() {
        return potencia;
    }

    public boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return "Radio " + marca + " (" + potencia + "W)";
    }
}
