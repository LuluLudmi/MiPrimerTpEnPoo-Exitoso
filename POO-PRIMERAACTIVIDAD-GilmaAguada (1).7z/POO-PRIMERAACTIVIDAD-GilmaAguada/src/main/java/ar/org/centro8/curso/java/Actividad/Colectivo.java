package ar.org.centro8.curso.java.Actividad;

import lombok.ToString;

@ToString(callSuper = true)

public class Colectivo extends Vehiculo {
    public Colectivo(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    @Override
    public String getTipoVehiculo() {
        return "Colectivo";
    }
}
