package ar.org.centro8.curso.java.Actividad;

import lombok.ToString;

@ToString(callSuper = true)

public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String color, String marca, String modelo, Double precio, Radio radio) {
        super(color, marca, modelo, precio);

        if (radio == null) {
            throw new IllegalArgumentException("ERROR: No se puede crear un Auto Nuevo sin radio.");
        }
        setRadio(radio); // Asignación válida
    }

    @Override
    public String getTipoVehiculo() {
        return "Auto Nuevo";
    }
}