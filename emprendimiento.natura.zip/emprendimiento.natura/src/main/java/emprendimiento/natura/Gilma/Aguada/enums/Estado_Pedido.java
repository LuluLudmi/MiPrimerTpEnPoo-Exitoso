package emprendimiento.natura.Gilma.Aguada.enums;

public enum Estado_Pedido {
    PENDIENTE,CONFIRMADO,ENVIADO,ENTREGADO,CANCELADO;
}
